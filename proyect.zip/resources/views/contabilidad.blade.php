@extends('layouts.app')
@section('content')

<div class="container">
<ul class="nav nav-tabs" id="interest_tabs">
    <!--top level tabs-->
  <li><a href="#maestro" data-toggle="tab">Maestro</a></li>
  <li><a href="#movimientos" data-toggle="tab">Movimientos</a></li>
  <li><a href="#reportes" data-toggle="tab">Reportes</a></li>
</ul>

<!--top level tab content-->
<div class="tab-content">
    <!--all tab menu-->
    <div id="maestro" class="tab-pane">
        <ul class="nav nav-tabs" id="all_tabs">
            <li><a href="#form_empresas" data-toggle="tab">Ingreso Empresas</a></li>
            <li><a href="#form_cuentas" data-toggle="tab">Plan de Cuentas</a></li>
            <li><a href="#form_clientes" data-toggle="tab">Información de Clientes</a></li>
            <li><a href="#form_prov_acree" data-toggle="tab">Información de Proveedores y Acreedores</a></li>
        </ul>
    </div>
    
    <!--brands tab menu-->
    <div id="movimientos" class="tab-pane">
        <ul class="nav nav-tabs" id="brands_tabs">
            <li><a href="#comprobantes" data-toggle="tab">Comprobantes</a></li>
            <li><a href="#ventas" data-toggle="tab">Ventas</a></li>
            <li><a href="#compras" data-toggle="tab">Compras</a></li>
            <li><a href="#centralizacion" data-toggle="tab">Centralización</a></li>
            <li><a href="#inventario" data-toggle="tab">Inventario</a></li>
            <li><a href="#aperturas" data-toggle="tab">Aperturas</a></li>
            <li><a href="#tesoreria" data-toggle="tab">Tesorería</a></li>
            <li><a href="#cartolas" data-toggle="tab">Cartolas</a></li>
            <li><a href="#honorarios" data-toggle="tab">Honorarios</a></li>
        </ul>
    </div>
  
    <!--media tab menu-->
    <div id="reportes" class="tab-pane">
        <ul class="nav nav-tabs" id="media_tabs">
            <li><a href="#info_empresas" data-toggle="tab">Información Empresas</a></li>
            <li><a href="#info_cuentas" data-toggle="tab">Información y Manejo de Cuentas</a></li>
            <li><a href="#info_terceros" data-toggle="tab">Información de Terceros</a></li>
            <li><a href="#rep_movimientos" data-toggle="tab">Movimientos</a></li>
            <li><a href="#lib_contables" data-toggle="tab">Libros Contables</a></li>
            <li><a href="#lib_auxiliares" data-toggle="tab">Libros Auxiliares</a></li>
            <li><a href="#estados_financieros" data-toggle="tab">Estados Financieros</a></li>
        </ul>
    </div>  
  
  
 </div>
  
    <!--all tab content-->
    <div class="tab-content">
        <div id="form_empresas" class="tab-pane">
            @include('contabilidad.agregar_empresa')
        </div>
        <div id="form_cuentas" class="tab-pane">
            @include('contabilidad.plancuentas')
        </div>
        <div id="form_clientes" class="tab-pane">
            @include('contabilidad.agregar_cliente')
        </div>
        <div id="form_prov_acree" class="tab-pane">
            @include('contabilidad.agregar_proveedores')
        </div>
    </div>

    <!--brands tab content-->
    <div class="tab-content">
        <div id="comprobantes" class="tab-pane">
            <i>Comprobantes</i>
        </div>
        <div id="ventas" class="tab-pane">
            <i>Ventas</i>
        </div>
        <div id="compras" class="tab-pane">
            <i>Compras</i>
        </div>
        <div id="centralizacion" class="tab-pane">
            <i>Centralizacion</i>
        </div>
        <div id="inventario" class="tab-pane">
            <i>Inventario</i>
        </div>
        <div id="aperturas" class="tab-pane">
            <i>Aperturas</i>
        </div>
        <div id="tesoreria" class="tab-pane">
            <i>Tesoreria</i>
        </div>
        <div id="cartolas" class="tab-pane">
            <i>Cartolas</i>
        </div>
        <div id="honorarios" class="tab-pane">
            <i>Honorarios</i>
        </div>
    </div>

    <!--media tab content-->
    <div class="tab-content">
        <div id="info_empresas" class="tab-pane">
            <i>Información Empresas</i>
        </div>
        <div id="info_cuentas" class="tab-pane">
            <i>Información y Manejo de Cuentas</i>
        </div>
        <div id="info_terceros" class="tab-pane">
            <i>Información de Terceros</i>
        </div>
        <div id="rep_movimientos" class="tab-pane">
            <i>Movimientos</i>
        </div>
        <div id="lib_contables" class="tab-pane">
            <i>Libros Contables</i>
        </div>
        <div id="lib_auxiliares" class="tab-pane">
            <i>Libros Auxiliares</i>
        </div>
        <div id="estados_financieros" class="tab-pane">
            <i>Estados Financieros</i>
        </div>
    </div>



</div>
        
@endsection
