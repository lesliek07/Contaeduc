<form>
  <div class="form-group">
    <label for="NombreEmpresaLabel">Nombre empresa:</label>
    <input type="input" class="form-control" id="CrearEmpresa" placeholder="Agregar empresa">
    <br></br>

    <label for="FechaEmpresaLabel">Fecha creación:</label>
    <input type="input" class="form-control" id="FechaEmpresa" placeholder="DD-MM-AAAA">
    <br></br>
  </div>
  <div class="form-group">
    <label for="RutEmpresaLabel">Rut Empresa:</label>
    <input type="input" class="form-control" id="rutempresa" placeholder="99.999.999-9">
    <br></br>

    <label for="GiroEmpresaLabel">Giro:</label>
    <input type="input" class="form-control" id="giroempresa" placeholder="Ingrese Giro">

    <label for="DirecciónEmpresaLabel">Dirección:</label>
    <input type="input" class="form-control" id="dirección"  placeholder="Ingrese Direccion">
    <br></br>
  </div>

  <div class="form-group">
    <label for="labelregion">Región</label>
    <select class="form-control" id="region">
      <option>O'higgins</option>
      <option>Metropolitana</option>
      <option>Maule</option>
    </select>
    <label for="ComunaEmpresaLabel">Comuna:</label>
    <input type="input" class="form-control" id="comuna" aria-describedby="emailHelp" placeholder="Ingrese comuna">

  </div>

  <div class="form-group">
      <input type="input" class="form-control" id="CorreoEmpresa1" aria-describedby="emailHelp" placeholder="Ingrese correo">
      <small id="emailHelp" class="form-text text-muted">Ingrese el correo de la empresa.</small>
      <br></br>
  </div>


  <div class="form-group">

    <label for="exampleInputPassword1">Contacto:</label>
    <input type="input" class="form-control" id="nombrecontacto" placeholder="Nombre Contacto">
    <label for="exampleInputPassword1">Representante Legal:</label>
    <input type="input" class="form-control" id="representantelegal" placeholder="Representante">
    <br></br>
    <label for="exampleInputPassword1">Rut representante legal:</label>
    <input type="input" class="form-control" id="rutrepresentante" placeholder="Rut representante">
  </div>

  <div class="form-check">
    <label class="form-check-label">
      <input type="checkbox" class="form-check-input">
      Validar campos
    </label>
  </div>
  <button type="submit" class="btn btn-primary">Crear Empresa</button>

</form>
