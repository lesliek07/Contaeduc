<form>
  <div class="form-group">
    <label for="NombreEmpresaLabel">Nombre empresa:</label>
    <input type="input" class="form-control" id="CrearEmpresa" placeholder="Agregar empresa">

    <label for="FechaEmpresaLabel">Fecha creación:</label>
    <input type="input" class="form-control" id="FechaEmpresa" placeholder="DD-MM-AAAA">
    <br></br>
  </div>

  <div class="form-group">
    <label for="RutEmpresaLabel">Rut:</label>
    <input type="input" class="form-control" id="rutempresa" placeholder="99.999.999-9">

    <label for="GiroEmpresaLabel">Giro:</label>
    <input type="input" class="form-control" id="giroempresa" placeholder="Giro">

    <label for="DirecciónEmpresaLabel">Dirección:</label>
    <input type="input" class="form-control" id="dirección"  placeholder="Agregar dirección">
    <br></br>
  </div>

  <div class="form-group">
    <label for="labelregion">Región</label>
    <select class="form-control" id="region">
      <option>O'higgins</option>
      <option>Metropolitana</option>
      <option>Maule</option>
    </select>
    <label for="ComunaEmpresaLabel">Comuna:</label>
    <input type="input" class="form-control" id="comuna" placeholder="Ingrese comuna">

    <label for="ComunaEmpresaLabel">Teléfono:</label>
    <input type="input" class="form-control" id="telefono" placeholder="Ingrese teléfono">

  </div>

  <div class="form-group">
      <input type="input" class="form-control" id="CorreoEmpresa1" placeholder="Ingrese correo">
      <small id="emailHelp" class="form-text text-muted">Ingrese el correo de la empresa.</small>
      <br></br>
  </div>


  <div class="form-group">

    <label for="exampleInputPassword1">Contacto:</label>
    <input type="input" class="form-control" id="nombrecontacto" placeholder="Nombre Contacto">
    <label for="exampleInputPassword1">Mail:</label>
    <input type="input" class="form-control" id="representantelegal" placeholder="Correo@server.com">
    <br></br>
    <label for="exampleInputPassword1">Cargo:</label>
    <input type="input" class="form-control" id="rutrepresentante" placeholder="Cargo">
  </div>

  <div class="form-check">
    <label class="form-check-label">
      <input type="checkbox" class="form-check-input">
      Validar campos
    </label>
  </div>
  <button type="submit" class="btn btn-primary">Agregar cliente</button>

</form>