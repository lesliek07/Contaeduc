<form>

  <div class="form-group">
    <div class="form-group">
     <label for="exampleSelect2">Cuenta</label>
     <br></br>
     <select class="form-control" id="cuentaid">
       <option>Activo</option>
       <option>Pasivo</option>
       <option>Patrimonio</option>

     </select>


      <label for="labelregion">Cuenta</label>
      <select class="form-control" id="region">
        <option>Corriente</option>
        <option>No corriente</option>
      </select>
    </div>
      <label for="codigocuentalabel">Codigo cuenta:</label>
      <input type="input" class="form-control" id="CrearEmpresa" placeholder="Agregar código">
      <label for="nombrecuentalabel">Nombre de la cuenta:</label>
      <input type="input" class="form-control" id="FechaEmpresa" placeholder="Nombre cuenta">
      <br></br>
  </div>

  <div class="form-group">
   <label for="patrimoniolabel">Patrimonio</label>
   <br></br>
   <select class="form-control" id="patrimonioid">
     <option>Capital</option>
     <option>Reservas</option>
     <option>Perdida</option>
    <option>Ganancia</option>
   </select>
   <div>


  <div class="form-check">
    <label class="form-check-label">
      <input type="checkbox" class="form-check-input">
      Validar campos
    </label>
  </div>
  <center><button type="submit" class="btn btn-primary">Agregar proveedor</button></center>

</form>
